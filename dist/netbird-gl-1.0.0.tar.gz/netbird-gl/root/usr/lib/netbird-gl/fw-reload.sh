#!/bin/sh
/usr/sbin/netbird-gl fw-reload
exit 0
