#!/bin/sh
case "$1" in
on | off) ;;
*) echo "Usage: $0 [on|off]"; exit 1 ;;
esac
/usr/sbin/netbird-gl switch exit "$1" </dev/null >/dev/null 2>&1 &
exit 0
